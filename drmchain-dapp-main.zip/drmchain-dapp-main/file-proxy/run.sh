# waitress-serve server
python3 server.py
