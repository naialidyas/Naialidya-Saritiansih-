import React from "react";

const Notfound = () => {
  return <h1 className="text-center">Page Not Found</h1>;
};

export default Notfound;
