cd truffle 
yarn install
truffle migrate 

cd ..
cd client
yarn install
yarn start